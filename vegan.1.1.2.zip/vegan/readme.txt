== Vegan WordPress Theme ==

Contributors: Aya Templates
Tags: blog, food-and-drink, education, two-columns, right-sidebar, custom-logo,
custom-background, custom-colors, custom-header, custom-menu, featured-images,
threaded-comments, translation-ready, sticky-post, theme-options, footer-widgets,
full-width-template, front-page-post-form

Requires at least: 4.3.0
Tested up to: 4.6.1

== Description ==

Vegan is a Fully Responsive WordPress Theme, a perfect choice for a website or
blog about healthy lifestyle, vegetarian or vegan recipes, vegan society, etc.
Features include built-in slider, multi-level drop-down menu, W3C markup validated,
right sidebar widget area, 3 Footer widget areas, full-width page template, footer copyright,
background color and image, FontAwesome integration, translation ready and much more.

== Installation ==

Manual installation:

1. Upload the theme folder to the /wp-content/themes/ directory

Installation using 'Add New Theme'

1. From your Admin UI (Dashboard), use the menu to select Themes -> Add New
2. Search for theme name
3. Click the 'Install' button to open the theme's repository listing
4. Click the 'Install' button

Activiation and Use

1. Activate the Theme through the 'Themes' menu in WordPress
2. See Appearance -> Theme Options to change theme specific options

== License ==

Vegan WordPress Theme, Copyright 2016 AyaTemplates.com
Vegan is distributed under the terms of the GNU GPL

Unless otherwise specified, all the theme files, scripts and images
are licensed under GNU General Public License version 2.

The exceptions to this license are as follows:

* Fontawesome is licensed under the terms of The MIT License
* Source: https://opensource.org/licenses/mit-license.html
*
* css/font-awesome.css - The MIT License (MIT), Reference: http://opensource.org/licenses/MIT
* css/font-awesome.min.css - The MIT License (MIT), Reference: http://opensource.org/licenses/MIT
* fonts/FontAwesome.otf SIL OFL 1.1 Reference: http://scripts.sil.org/OFL
* fonts/fontawesome-webfont.eot SIL OFL 1.1 Reference: http://scripts.sil.org/OFL
* fonts/fontawesome-webfont.svg SIL OFL 1.1 Reference: http://scripts.sil.org/OFL
* fonts/fontawesome-webfont.ttf SIL OFL 1.1 Reference: http://scripts.sil.org/OFL
* fonts/fontawesome-webfont.woff SIL OFL 1.1 Reference: http://scripts.sil.org/OFL
* fonts/fontawesome-webfont.woff2 SIL OFL 1.1 Reference: http://scripts.sil.org/OFL
*
* PT Sans (default theme font), Released under Apache License, version 2.0 license - http://www.apache.org/licenses/LICENSE-2.0.html
*
* js/jquery.easing.1.3.js BSD License Reference: http://www.linfo.org/bsdlicense.html
*
* js/ayaSlider.js MIT license Reference: http://www.opensource.org/licenses/mit-license.php
* js/ayaSlider-minified.js MIT license Reference: http://www.opensource.org/licenses/mit-license.php
*
* images/slider/1.jpg CC0 Public Domain Reference: http://pixabay.com/go/?t=%2Fservice%2Fterms%2F%23download_terms,
* Image Source: https://pixabay.com/en/smoothie-raspberry-food-healthy-1427436/
*
* images/slider/2.jpg CC0 Public Domain Reference: http://pixabay.com/go/?t=%2Fservice%2Fterms%2F%23download_terms,
* Image Source: https://pixabay.com/en/dish-meal-berries-blackberries-1209170/
*
* images/slider/3.jpg CC0 Public Domain Reference: http://pixabay.com/go/?t=%2Fservice%2Fterms%2F%23download_terms,
* Image Source: https://pixabay.com/en/raspberry-fruits-fresh-red-427390/
*
* screenshot.png (slider and post thumbnail image) CC0 Public Domain Reference: http://pixabay.com/go/?t=%2Fservice%2Fterms%2F%23download_terms, Image Source: https://pixabay.com/en/smoothie-raspberry-food-healthy-1427436/

== Homepage Slider ==

By Default the Homepage slider is disabled, but it can be easily enabled:

1. Login to your Admin Panel

2. Navigate to Left Menu -> Appearance -> Customize -> 'Slider' Section

3. Check the 'Display Slider' checkbox

4. Save the changes by clicking on the 'Save & Publish' button

== Contacts ==

Author Website: https://ayatemplates.com
